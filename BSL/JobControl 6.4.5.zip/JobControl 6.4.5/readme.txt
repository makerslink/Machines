TROTEC GMBH
http://www.troteclaser.com


TROTEC MAKES NO WARRANTIES, EITHER
EXPRESS OR IMPLIED, REGARDING THE ENCLOSED SOFTWARE, INCLUDING
MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  

TROTEC EXCLUDES ANY WARRANTY COVERAGE FOR INCIDENTAL OR 
CONSEQUENTIAL DAMAGES.


Trotec JobControl, version 6.4.5, 15/12/2005, (c) Trotec GmbH 2005


Release Notes:
-------------

6.4.5 is the preliminary final update to all previously released versions 5.x.x - 6.x.x

6.4.5 may be installed:
- stand alone
- as update
- coexistent to 7.x.x

difference 6.3.1 to 6.4.5:
- exhaust feedback
  issue: noisy environment caused the exhaust to report 'not ready' -> JobControl paused processing
  fix: delayed pause after exhaust feedback has changed
- communication
  issue: intermittent communication errors (-204)
  fix: several improvements in communication module
- material dialog
  issue: material settings got lost after process kind (engrave-cut-skip) was modified
  fix: material settings stored separately for each process kind


Supported Engraver Types:
------------------------

- Speedy Compact
- Speedy
- Speedy II


System Requirements:
-------------------

- Intel Pentium IV 1.4 GHz class or compatible

- 512 MB RAM

- CD/ROM or DVD/ROM drive

- 20MB free harddisk space

- Supported Operating Systems:
  Microsoft� Windows� 98/ME
  Microsoft� Windows� 2000 Pro SP4
  Microsoft� Windows� XP Pro/Home SP2