April 16, 2004

This zip archive contains drivers and associated documentation  to support FTDI's FT8U100AX, FT8U232AM and FT8U245AM USB controller products. 

The documents on this disk are 

* 905 Release Info.doc - Windows 98 release notes
* 2154 Release Info.pdf - Windows 2k release notes
* ComPort - Guide to changing COM ports under Windows 98

Please download the following documents from our web page http://www.ftdichip.com - select "Application Notes" from the LHS Navigation panel.
 
* AN232-3 - Windows 98 install guide
* AN232-5 - Windows 2k install guide

Further information about FTDI's products as well as updates of drivers can be obtained from FTDI's web site at URL http://www.ftdichip.com

We recommend that customers join the FTDI Newsletter. The FTDI NewsLetter is a e-mail based service which allows you to receive the latest FTDI related news, product releases, current driver version information. To join the FTDI NewsLetter, go to our web site http://www.ftdichip.com and click on the "FTDI NewsLetter" button on the LHS navigation panel.

For technical support on our products and drivers, please e-mail support@ftdichip.com

For sales enquiries please e-mail sales@ftdichip.com

For general enquiries please e-mail admin@ftdichip.com






